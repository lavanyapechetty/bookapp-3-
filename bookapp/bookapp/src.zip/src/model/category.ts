export interface Category {
  catid: number;
  catdescription: string;
 
}