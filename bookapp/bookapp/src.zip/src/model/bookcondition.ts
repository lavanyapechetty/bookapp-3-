export interface BookCondition {
    ranks: number;
    description: string;
    full_Description: string;
    price: number;
  }