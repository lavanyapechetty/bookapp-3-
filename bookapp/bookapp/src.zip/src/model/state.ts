export interface State{
    stateCode: string;
    stateName: string;
  }
  
  