export interface Reviewer {
    reviewerid: number;
    employedby: string;
    name: string;
  }