export interface Permrole {
    rolenumber: number;
    permrole: string;
   
  }