export interface BookReview {
    isbn: string;
    reviewerid: number;
    rating: number;
    comments: string;
 
    // constructor(isbn: string, reviewerid: number, rating: number, comments: string) {
    //   this.isbn = isbn;
    //   this.reviewerid = reviewerid;
    //   this.rating = rating;
    //   this.comments = comments;
    // }
  }