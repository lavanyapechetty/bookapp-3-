export interface Inventory {
    inventoryId: number;
    isbn: string;
    ranks: number;
    purchased: boolean;
   
   
    }