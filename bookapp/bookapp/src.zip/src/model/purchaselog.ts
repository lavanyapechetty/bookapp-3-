export interface PurchaseLog {
    users: {
      userid: number;
     
    };
    inventory: {
      inventoryid: number;
     
    };
  }